
#
# Emulation, Calibration, Model Averaging Toy Example
# For BAND
# Fall, 2020
# M.T. Pratola
##########################################################################################################################


#
# The Ball Drop Experiment
#
##########################################################################################################################
source("gpfuns.r")
source("regression.r")


#
# 1. Emulating the single-parameter model when gravity is known, initial velocity=0, initial height=25m.
#    theta=g=-9.8 m/s^2
##########################################################################################################################

# no drag version of ball drop
# t is time in seconds
# h0 is drop height in meters
# m is mass in kg
fM1<-function(t,g=9.8,m=1,h0=60) {
	h0+0.5*(-g)*t^2
}

# quadratic drag version of ball drop, with drag coefficient gamma.
# gamma=0 is the no-drag version.
# Based on Ch2 of Taylor (PDF is in the repo).
# D is diameter of ball in meters
# h0 is drop height in meters
# m is mass in kg
# t is time in seconds
# gamma is coefficient in units N*s^2/m^4
fM2<-function(t,gamma,g,D=0.1,m=1,h0=60) {
	n=length(t)
	if(length(g)==1) g=rep(g,n)
	if(length(gamma)==1) gamma=rep(gamma,n)
	height=rep(0,n)

	for(i in 1:n) {
		c=gamma[i]*D^2
		vter=sqrt(m*g[i]/c)

		if(gamma[i]>0.0)
			height[i]=h0-(vter^2)/g[i]*log(cosh(g[i]*t[i]/vter))
		else
			height[i]=fM1(t[i],g[i],m,h0)
	}

	height
}

set.seed(99)
n=5
k=1
x.design=matrix(runif(n,0,3),ncol=k)
f.obs=fM1(x.design)


# Typically model things on normalized scale to simplify specification of priors
mf=mean(f.obs)
sdf=sd(f.obs)
f=(f.obs-mf)/sdf

plot(x.design,f)


l.d=makedistlist(x.design)
pi=list(az=5,bz=5,rhoa=rep(1,k),rhob=rep(5,k))
mh=list(rr=0.05)

# 1a. Fit Bayesian emulator
############################
fit=regress(f,l.d,5000,pi,mh,last=2000,adapt=TRUE)

par(mfrow=c(1,2))
plot(fit$lambdaz,type='l',xlab="draw",ylab="lambdaz",ylim=c(0,3))
plot(fit$rhoz,type='l',xlab="draw",ylab="rhoz",ylim=c(0,1))

# 1b. Perform emulation
############################
x.pred=matrix(seq(0,3,length=100),ncol=1)
fitp=predict(x.pred,x.design,fit)

par(mfrow=c(1,1))
plot(x.design,f)
lines(x.pred,fitp$fp,col="blue")
lines(x.pred,fitp$fp-2*fitp$fp.sd,col="blue",lty=2)
lines(x.pred,fitp$fp+2*fitp$fp.sd,col="blue",lty=2)




#
# 2. Now consider we don't know gravity.  We could emulate the full 2D space.  Although typically there
#    is more dense sampling in the inputs than in the parameters.
##########################################################################################################################

set.seed(99)
n=5
k=2
x.design=as.matrix(expand.grid(seq(0.1,2.9,length=n),runif(n,5,15)))
colnames(x.design)=c("time","gravity")
f.obs=fM1(x.design[,"time"],x.design[,"gravity"])

# Typically model things on normalized scale to simplify specification of priors
mf=mean(f.obs)
sdf=sd(f.obs)
f=(f.obs-mf)/sdf


l.d=makedistlist(x.design)
pi=list(az=5,bz=5,rhoa=rep(1,k),rhob=rep(5,k))
mh=list(rr=0.05)

# 2a. Fit Bayesian emulator
############################
fit=regress(f,l.d,5000,pi,mh,last=2000,adapt=TRUE)

par(mfrow=c(1,2))
plot(fit$lambdaz,type='l',xlab="draw",ylab="lambdaz",ylim=c(0,0.5))
plot(fit$rhoz,type='l',xlab="draw",ylab="rhoz",ylim=c(0,1))


# 2b. Perform emulation
############################
np=20
x.pred=as.matrix(expand.grid(seq(0,3,length=np),seq(5,15,length=np)))
fitp=predict(x.pred,x.design,fit)

fhat=fitp$fp*sdf+mf
fptrue=fM1(x.pred[,1],x.pred[,2])
mean((fptrue-fhat)^2)
plot(fptrue,fhat)
abline(0,1)

# 2c. We can 3D Plot the emulated model space
############################



#
# 3. Now consider we don't know gravity.  But here we are going to estimate it using calibration, as 
#    well as using the calibrated model to make probabilistic predictions.
##########################################################################################################################

set.seed(99)
n=3
k=2
#x.design=as.matrix(expand.grid(seq(0.1,0.9,length=n),runif(n,5,15)))
x.design=as.matrix(expand.grid(seq(0.1,2.9,length=n),c(8,12)))
colnames(x.design)=c("time","gravity")
f.obs=fM1(x.design[,"time"],x.design[,"gravity"])

# Typically model things on normalized scale to simplify specification of priors
mf=mean(f.obs)
sdf=sd(f.obs)
yc=(f.obs-mf)/sdf

g.true=9.8
nf=3
set.seed(7)
tobs=runif(nf,0,3)
y.true=fM1(tobs,g.true)
y.true=(y.true-mf)/sdf
yf=y.true+rnorm(n,sd=0.01)
yf.unscaled=yf*sdf+mf # only needed for RGL plots below.

# Setup the things required for the calibration model
th.init=0
d.th=matrix(c(tobs,rep(th.init,nf)),ncol=2,byrow=FALSE)

# Scale design and d.th.  Here, the first dimension (time) is already on [0,1] so we only have to scale the parameter dimension of design.
design=x.design
r2=range(x.design[,2])
design[,2]=(design[,2]-r2[1])/(r2[2]-r2[1])

nc=length(yc)
y=c(yf,yc)

design.all=rbind(d.th,design)
l.des=makedistlist(design.all)

ncdims=1
nxdims=1
ninfo=list(npred=0,nf=nf,nc=nc,ncdims=ncdims)

# finally, setup the prediction grid
npred=30
design.pred=as.matrix(expand.grid(seq(0,3,length=npred),th.init))
dpred.all=rbind(design.pred,d.th,design)
l.pred=makedistlist(dpred.all)
ninfo.pred=list(npred=npred,nf=nf,nc=nc,ncdims=ncdims)


# 3a. Fit Bayesian calibration model
############################
source("calibration.r")

pii=list(af=100,bf=1,az=5,bz=5,adel=50,bdel=5,rhoa=rep(5,nxdims),rhob=rep(1,nxdims),
	    psia=rep(5,ncdims),psib=rep(1,ncdims),rdla=rep(5,nxdims),rdlb=rep(5,nxdims))
mh=list(rr=.03,rp=.1,re=.1,rf=50,rz=.5,rl=.7,rth=.15)

set.seed(88) # just to replicate my run
fit=calibrate(y,l.des,ninfo,2000,pii,mh,last=1000,rho.force=0.8,psi.force=0.7)


# 3b. Draw posterior predictions
############################
fitp=predict(fit,l.pred,ninfo.pred)


# 3c. Make some plots
############################
eta=fitp$eta.pred*sdf+mf
zz=fitp$z.pred*sdf+mf
bias=zz-eta
eta.mu=apply(eta,2,mean)
eta.sd=apply(eta,2,sd)
zz.mu=apply(zz,2,mean)
zz.sd=apply(zz,2,sd)
bias.mu=apply(bias,2,mean)
bias.sd=apply(bias,2,sd)

#plot priors
par(mfrow=c(2,2))
plot(density(rgamma(1e5,shape=pii$af,rate=pii$bf)),main="",xlab="lambdaf prior")
plot(density(rgamma(1e5,shape=pii$az,rate=pii$bz)),main="",xlab="lambdaz prior")
plot(density(rgamma(1e5,shape=pii$adel,rate=pii$bdel)),main="",xlab="lambdadel prior")
plot(density(rbeta(1e5,pii$rhoa[1],pii$rhob[1])),main="",xlab="corr. param prior")

par(mfrow=c(3,3))
plot(fit$lambdaf,type='l',xlab="lambdaf")
plot(fit$lambdaz,type='l',xlab="lambdaz")
plot(fit$lambdadel,type='l',xlab="lambdadel")
plot(fit$rhoz,type='l',xlab="rhoz",ylim=c(0,1))
plot(fit$psiz[,1],type='l',xlab="psiz.1",ylim=c(0,1))
plot(fit$rhodel,type='l',xlab="rhodel",ylim=c(0,1))
plot(fit$theta[,1]*(r2[2]-r2[1])+r2[1],type='l',xlab="theta.1",ylim=c(5,15),ylab="")

par(mfrow=c(1,1))
plot(density(fit$theta[,1]*(r2[2]-r2[1])+r2[1]),xlab="theta.1",xlim=c(5,15),main="")
abline(v=9.8,lty=2)

par(mfrow=c(1,1))
plot(d.th[,1],yf,pch=20,col="red",ylim=c(-5,3),xlim=c(0,3),xlab="x",ylab="response")
points(design[,1],yc,pch=20,col="grey")
lines(design.pred[,1],fitp$z.mu,col="green")
lines(design.pred[,1],fitp$z.mu-1.96*fitp$z.sd,col="green",lty=2)
lines(design.pred[,1],fitp$z.mu+1.96*fitp$z.sd,col="green",lty=2)
lines(design.pred[,1],fitp$eta.mu,col="blue")
lines(design.pred[,1],fitp$eta.mu-1.96*fitp$eta.sd,col="blue",lty=2)
lines(design.pred[,1],fitp$eta.mu+1.96*fitp$eta.sd,col="blue",lty=2)
lines(design.pred[,1],bias.mu,col="orange")
lines(design.pred[,1],bias.mu-1.96*bias.sd,col="orange",lty=2)
lines(design.pred[,1],bias.mu+1.96*bias.sd,col="orange",lty=2)

cortb=cor(fit$theta[,1],apply(bias,1,mean)) # uncorrelated
par(mfrow=c(1,1))
plot(fit$theta[,1]*(r2[2]-r2[1])+r2[1],apply(bias,1,mean),xlab="theta.1",ylab="E[bias]") #plot the theta.2 draws vs the mean (over xpred) bias to show the correlation


# 4. Make nice model space 3D plots
############################
library(rgl)
ntime=100
ngrav=100
tgrid=seq(0,3,length=ntime)
ggrid=seq(5,15,length=ngrav)
grid=as.matrix(expand.grid(tgrid,ggrid))
colnames(grid)=c("time","gravity")
sim=fM1(grid[,"time"],grid[,"gravity"])


par3d(cex=3)
persp3d(tgrid,ggrid,sim,col="grey100",xlab="",ylab="",sep="",zlab="",xlim=c(0,3),ylim=c(5,15),zlim=c(0,70),box=FALSE,axes=FALSE)
title3d("(a)",line=1)  # really good at centering...
plot3d(x.design[,1],x.design[,2],f.obs,type="s",radius=1.2,col="green",add=TRUE)
plot3d(d.th[,1],rep(15,nf),yf.unscaled,type="s",radius=1.2,col="red",add=TRUE)
for(i in 1:nf)
	abclines3d(d.th[i,1],15,yf.unscaled[i],a=0,c=0,b=diag(3),col="red",lwd=3)
axis3d("x--",labels=T,tick=T,box=T)
axis3d("y+-",labels=T,tick=T,box=T)
axis3d("z--",labels=T,tick=T,box=T)
mtext3d("time (s)",edge="x--",line=3)
mtext3d("gravity (m/s^2)",edge="y-+",line=2)
mtext3d("height (m)",edge="z--",line=4)
#rgl.snapshot("toy1.png")


th.dens=density(fitp$theta*(r2[2]-r2[1])+r2[1])
th.mu=mean(fitp$theta*(r2[2]-r2[1])+r2[1])
par3d(cex=3)
persp3d(tgrid,ggrid,sim,col="grey100",xlab="",ylab="",zlab="",xlim=c(0,3),ylim=c(5,15),zlim=c(0,70),box=FALSE,axes=FALSE)
title3d("(b)",line=1)  # really good at centering...
plot3d(x.design[,1],x.design[,2],f.obs,type="s",radius=1.2,col="green",add=TRUE)
eta=fitp$eta.pred*sdf+mf
for(i in seq(1,1000,length=100))
	plot3d(design.pred[,1],rep(fitp$theta[i]*(r2[2]-r2[1])+r2[1],npred),eta[i,],type="l",add=TRUE,col="blue")
plot3d(d.th[,1],rep(th.mu,nf),yf.unscaled,type="s",radius=1.2,col="red",add=TRUE)
plot3d(3-3*th.dens$y,th.dens$x,rep(0,length(th.dens$x)),type='l',col="red",lwd=3,add=TRUE)
axis3d("x--",labels=T,tick=T,box=T)
axis3d("y+-",labels=T,tick=T,box=T)
axis3d("z--",labels=T,tick=T,box=T)
mtext3d("time (s)",edge="x--",line=1)
mtext3d("gravity (m/s^2)",edge="y-+",line=2)
mtext3d("height (m)",edge="z--",line=2)
#rgl.snapshot("toy2.png")


png("toy3.png",width=508,height=508)
par(mar=c(5,5,4,5)+.3,cex.lab=2.7,cex.axis=2.2)
plot(d.th[,1],yf.unscaled,pch=20,cex=3,col="red",xlim=c(0,3),ylim=c(0,70),xlab="time (s)",ylab="height (m)")
lines(design.pred[,1],zz.mu,col="green",lwd=2)
lines(design.pred[,1],zz.mu-1.96*zz.sd,col="green",lty=2)
lines(design.pred[,1],zz.mu+1.96*zz.sd,col="green",lty=2)
lines(design.pred[,1],eta.mu,col="blue",lwd=2)
lines(design.pred[,1],eta.mu-1.96*eta.sd,col="blue",lty=2)
lines(design.pred[,1],eta.mu+1.96*eta.sd,col="blue",lty=2)
par(new=TRUE)
plot(design.pred[,1],bias.mu,col="orange",type='l',lwd=2,xlim=c(0,3),ylim=c(-50,50),axes=FALSE,bty="n",xlab="",ylab="")
lines(design.pred[,1],bias.mu-1.96*bias.sd,col="orange",lty=2)
lines(design.pred[,1],bias.mu+1.96*bias.sd,col="orange",lty=2)
axis(side=4,at=pretty(c(-10,10)))
abline(h=0,col="grey",lty=3,lwd=2)
mtext("discrepancy (m)",side=4,line=3,cex=2.7)
mtext("(c)",line=2,adj=1,cex=2.7)
dev.off()




#
# 5. Now consider there is also (quadratic) drag.  But maybe the non-drag
#    model is cheaper, so we will have mostly non-drag runs (gamma=0) along
#    with a few runs of the "more expensive drag" model (gamma>0).
##########################################################################################################################

set.seed(99)
n=10
k=3
x.design1=matrix(c(0,2,0,
				   1,5,0,
				   2,8,0,
				   3,1,0,
				   4,4,0,
				   5,7,0,
				   6,0,0,
				   7,3,0,
				   8,6,0,
				   9,9,0),byrow=T,ncol=3)
x.design1=x.design1/10 # rescale to 0,1
x.design1[,1]=x.design1[,1]*3 # rescale to 0,3
x.design1[,2]=x.design1[,2]*(15-5)+5 # rescale to 5,15
x.design1[,3]=x.design1[,3]*100 # rescale to 0,100

x.design2=matrix(c(0,6,4,
				   1,1,5,
				   2,3,0,
				   3,4,9,
				   4,8,1,
				   5,9,6,
				   6,0,7,
				   7,2,2,
				   8,5,8,
				   9,7,3),byrow=T,ncol=3)
x.design2=x.design2/10 # rescale to 0,1
x.design2[,1]=x.design2[,1]*3 # rescale to 0,3
x.design2[,2]=x.design2[,2]*(15-5)+5 # rescale to 5,15
x.design2[,3]=x.design2[,3]*100 # rescale to 0,100

x.design=rbind(x.design1,
	x.design2)
colnames(x.design)=c("time","gravity","dragcoef")
f.obs=fM2(x.design[,"time"],x.design[,"dragcoef"],x.design[,"gravity"])

# Typically model things on normalized scale to simplify specification of priors
mf=mean(f.obs)
sdf=sd(f.obs)
yc=(f.obs-mf)/sdf

g.true=9.8
gamma.true=40
nf=7
set.seed(7)
times=seq(0.1,2.9,length=nf)+runif(nf,min=-.1,max=.1)
y.true=fM2(times,gamma.true,g.true)
y.true=(y.true-mf)/sdf
yf=y.true+rnorm(nf,sd=0.01)
yf.unscaled=yf*sdf+mf # only needed for RGL plots below.

# Setup the things required for the calibration model
th.init=c(0,0)
d.th=matrix(c(times,rep(th.init[1],nf),rep(th.init[2],nf)),ncol=k,byrow=FALSE)

# Scale design and d.th.  Here, the first dimension (time) is already on [0,1] so we only have to scale the parameter dimension of design.
design=x.design
r2=c(5,15) #range(x.design[,2])
design[,2]=(design[,2]-r2[1])/(r2[2]-r2[1])
r3=c(0,100) #range(x.design[,3])
design[,3]=(design[,3]-r3[1])/(r3[2]-r3[1])

nc=length(yc)
y=c(yf,yc)

design.all=rbind(d.th,design)
l.des=makedistlist(design.all)

ncdims=2
nxdims=1
ninfo=list(npred=0,nf=nf,nc=nc,ncdims=ncdims)

# finally, setup the prediction grid
npred=30
design.pred=as.matrix(expand.grid(seq(0,3,length=npred),th.init[1],th.init[2]))
dpred.all=rbind(design.pred,d.th,design)
l.pred=makedistlist(dpred.all)
ninfo.pred=list(npred=npred,nf=nf,nc=nc,ncdims=ncdims)


# 5a. Fit Bayesian calibration model
############################
source("calibration.r")

pii=list(af=100,bf=1,az=5,bz=5,adel=500,bdel=5,rhoa=rep(5,nxdims),rhob=rep(1,nxdims),
	    psia=rep(5,ncdims),psib=rep(1,ncdims),rdla=rep(5,nxdims),rdlb=rep(5,nxdims))
mh=list(rr=.03,rp=.1,re=.1,rf=50,rz=.5,rl=.7,rth=.15)

set.seed(88) # just to replicate my run
fit=calibrate(y,l.des,ninfo,5000,pii,mh,last=1000,rho.force=0.9,psi.force=0.28,rhodel.force=0.7)



# 5b. Draw posterior predictions
############################
fitp=predict(fit,l.pred,ninfo.pred)



# 5c. Make some plots
############################
eta=fitp$eta.pred*sdf+mf
zz=fitp$z.pred*sdf+mf
bias=zz-eta
eta.mu=apply(eta,2,mean)
eta.sd=apply(eta,2,sd)
zz.mu=apply(zz,2,mean)
zz.sd=apply(zz,2,sd)
bias.mu=apply(bias,2,mean)
bias.sd=apply(bias,2,sd)

#plot priors
par(mfrow=c(2,2))
plot(density(rgamma(1e5,shape=pii$af,rate=pii$bf)),main="",xlab="lambdaf prior")
plot(density(rgamma(1e5,shape=pii$az,rate=pii$bz)),main="",xlab="lambdaz prior")
plot(density(rgamma(1e5,shape=pii$adel,rate=pii$bdel)),main="",xlab="lambdadel prior")
plot(density(rbeta(1e5,pii$rhoa[1],pii$rhob[1])),main="",xlab="corr. param prior")

par(mfrow=c(3,3))
plot(fit$lambdaf,type='l',xlab="lambdaf")
plot(fit$lambdaz,type='l',xlab="lambdaz")
plot(fit$lambdadel,type='l',xlab="lambdadel")
plot(fit$rhoz,type='l',xlab="rhoz",ylim=c(0,1))
plot(fit$psiz[,1],type='l',xlab="psiz.1",ylim=c(0,1))
plot(fit$rhodel,type='l',xlab="rhodel",ylim=c(0,1))
plot(fit$theta[,1]*(r2[2]-r2[1])+r2[1],type='l',xlab="theta.1",ylim=c(5,15),ylab="")
plot(fit$theta[,2]*(r3[2]-r3[1])+r3[1],type='l',xlab="theta.1",ylim=c(0,100),ylab="")

par(mfrow=c(1,2))
plot(density(fit$theta[,1]*(r2[2]-r2[1])+r2[1]),xlab="theta.1",xlim=c(5,15),main="")
abline(v=g.true,lty=2)
plot(density(fit$theta[,2]*(r3[2]-r3[1])+r3[1]),xlab="theta.2",xlim=c(0,100),main="")
abline(v=gamma.true,lty=2)

par(mfrow=c(1,1))
plot(d.th[,1],yf.unscaled,pch=20,col="red",ylim=c(-5,60),xlab="x",ylab="response")
points(design[,1],f.obs,pch=20,col="grey")
lines(design.pred[,1],zz.mu,col="green")
lines(design.pred[,1],zz.mu-1.96*zz.sd,col="green",lty=2)
lines(design.pred[,1],zz.mu+1.96*zz.sd,col="green",lty=2)
lines(design.pred[,1],eta.mu,col="blue")
lines(design.pred[,1],eta.mu-1.96*eta.sd,col="blue",lty=2)
lines(design.pred[,1],eta.mu+1.96*eta.sd,col="blue",lty=2)
abline(h=0,lty=3)
lines(design.pred[,1],bias.mu,col="orange")
lines(design.pred[,1],bias.mu-1.96*bias.sd,col="orange",lty=2)
lines(design.pred[,1],bias.mu+1.96*bias.sd,col="orange",lty=2)

cortb1=cor(fit$theta[,1],apply(bias,1,mean)) # uncorrelated
cortb2=cor(fit$theta[,2],apply(bias,1,mean)) # uncorrelated
par(mfrow=c(1,2))
plot(fit$theta[,1]*(r2[2]-r2[1])+r2[1],apply(bias,1,mean),xlab="theta.1",ylab="E[bias]") #plot the theta.2 draws vs the mean (over xpred) bias to show the correlation
plot(fit$theta[,2]*(r3[2]-r3[1])+r3[1],apply(bias,1,mean),xlab="theta.2",ylab="E[bias]") #plot the theta.2 draws vs the mean (over xpred) bias to show the correlation



# 5d. Make nice model space 3D plots
############################
library(rgl)
ntime=100
ngrav=100
ngam=100
tgrid=seq(0,3,length=ntime)
ggrid=seq(5,15,length=ngrav)
grid=as.matrix(expand.grid(tgrid,ggrid))
colnames(grid)=c("time","gravity")
sim=fM1(grid[,"time"],grid[,"gravity"])
sim1=fM2(grid[,"time"],25,grid[,"gravity"])
sim2=fM2(grid[,"time"],75,grid[,"gravity"])



par3d(cex=3)
persp3d(tgrid,ggrid,sim,col="grey100",xlab="",ylab="",zlab="",xlim=c(0,3),ylim=c(5,15),zlim=c(0,70),box=FALSE,axes=FALSE)
title3d("(a)",line=1)  # really good at centering...
material3d("grey100",alpha=0.3)
persp3d(tgrid,ggrid,sim2,col="grey100",xlab="",ylab="",zlab="",xlim=c(0,3),ylim=c(5,15),zlim=c(0,70),box=FALSE,axes=FALSE,add=TRUE)
material3d("grey100",alpha=0.8)
persp3d(tgrid,ggrid,sim1,col="grey100",xlab="",ylab="",zlab="",xlim=c(0,3),ylim=c(5,15),zlim=c(0,70),box=FALSE,axes=FALSE,add=TRUE)
material3d("grey100",alpha=1.0)
persp3d(tgrid,ggrid,sim,col="grey100",xlab="",ylab="",zlab="",xlim=c(0,3),ylim=c(5,15),zlim=c(0,70),box=FALSE,axes=FALSE,add=TRUE)
#plot3d(x.design[1:40,1],x.design[1:40,2],f.obs[1:40],type="s",radius=0.4,col="green",add=TRUE)
#plot3d(x.design[41:80,1],x.design[41:80,2],f.obs[41:80],type="s",radius=0.4,col="black",add=TRUE)
#plot3d(d.th[,1],rep(15,nf),yf.unscaled,type="s",radius=0.4,col="red",add=TRUE)
for(i in 1:nf)
	abclines3d(d.th[i,1],15,yf.unscaled[i],a=0,c=0,b=diag(3),col="red",lwd=3)
for(i in seq(1,1000,length=100))
	if( (fit$theta[i,1]*(r2[2]-r2[1])+r2[1]) <11)
		lines3d(design.pred[2:29,1],fit$theta[i,1]*(r2[2]-r2[1])+r2[1],fitp$z.pred[i,2:29]*sdf+mf,col="blue")
title3d("(a)",line=1)  # really good at centering...
axis3d("x--",labels=T,tick=T,box=T)
axis3d("y+-",labels=T,tick=T,box=T)
axis3d("z--",labels=T,tick=T,box=T)
mtext3d("time (s)",edge="x--",line=1)
mtext3d("gravity (m/s^2)",edge="y-+",line=2)
mtext3d("height (m)",edge="z--",line=2)
#rgl.snapshot("toy4.png")




png("toy5.png",width=508,height=508)
par(mfrow=c(1,1))
par(mar=c(5,5,4,5)+.3,cex.lab=2.7,cex.axis=2.2)
plot(d.th[,1],yf.unscaled,pch=20,cex=3,col="red",xlim=c(0,3),ylim=c(0,70),xlab="time (s)",ylab="height (m)")
lines(design.pred[,1],zz.mu,col="green",lwd=2)
lines(design.pred[,1],zz.mu-1.96*zz.sd,col="green",lty=2)
lines(design.pred[,1],zz.mu+1.96*zz.sd,col="green",lty=2)
lines(design.pred[,1],eta.mu,col="blue",lwd=2)
lines(design.pred[,1],eta.mu-1.96*eta.sd,col="blue",lty=2)
lines(design.pred[,1],eta.mu+1.96*eta.sd,col="blue",lty=2)
par(new=TRUE)
plot(design.pred[,1],bias.mu,col="orange",type='l',lwd=2,xlim=c(0,3),ylim=c(-50,50),axes=FALSE,bty="n",xlab="",ylab="")
lines(design.pred[,1],bias.mu-1.96*bias.sd,col="orange",lty=2)
lines(design.pred[,1],bias.mu+1.96*bias.sd,col="orange",lty=2)
axis(side=4,at=pretty(c(-10,10)))
abline(h=0,col="grey",lty=3,lwd=2)
mtext("discrepancy (m)",side=4,line=3,cex=2.7)
mtext("(b)",line=2,adj=1,cex=2.7)
dev.off()




par(mfrow=c(1,2))
plot(density(fit$theta[,1]*(r2[2]-r2[1])+r2[1]),xlab=expression(theta[1]),xlim=c(5,15),main="")
abline(v=g.true,lty=2)
plot(density(fit$theta[,2]*(r3[2]-r3[1])+r3[1]),xlab=expression(theta[2]),xlim=c(0,100),main="")
abline(v=gamma.true,lty=2)



#
# 6. Similar setup as 5, i.e. true model is with drag.  But let's see how the
#    calibration for gravity goes if we use the wrong model.
##########################################################################################################################

set.seed(99)
n=10
k=2
x.design1=matrix(c(0,2,0,
				   1,5,0,
				   2,8,0,
				   3,1,0,
				   4,4,0,
				   5,7,0,
				   6,0,0,
				   7,3,0,
				   8,6,0,
				   9,9,0),byrow=T,ncol=3)
x.design1=x.design1/10 # rescale to 0,1
x.design1[,1]=x.design1[,1]*3 # rescale to 0,3
x.design1[,2]=x.design1[,2]*(15-5)+5 # rescale to 5,15
x.design1[,3]=x.design1[,3]*100 # rescale to 0,100

x.design=x.design1[,1:2]
colnames(x.design)=c("time","gravity")
f.obs=fM1(x.design[,"time"],x.design[,"gravity"])

# Typically model things on normalized scale to simplify specification of priors
mf=mean(f.obs)
sdf=sd(f.obs)
yc=(f.obs-mf)/sdf

g.true=9.8
gamma.true=40
nf=7

set.seed(7)
times=seq(0.1,2.9,length=nf)+runif(nf,min=-.1,max=.1)
y.true=fM2(times,gamma.true,g.true)
y.true=(y.true-mf)/sdf
yf=y.true+rnorm(nf,sd=0.01)
yf.unscaled=yf*sdf+mf # only needed for RGL plots below.

# Setup the things required for the calibration model
th.init=c(0)
d.th=matrix(c(times,rep(th.init[1],nf)),ncol=k,byrow=FALSE)

# Scale design and d.th.  Here, the first dimension (time) is already on [0,1] so we only have to scale the parameter dimension of design.
design=x.design
r2=c(5,15) #range(x.design[,2])
design[,2]=(design[,2]-r2[1])/(r2[2]-r2[1])

nc=length(yc)
y=c(yf,yc)

design.all=rbind(d.th,design)
l.des=makedistlist(design.all)

ncdims=1
nxdims=1
ninfo=list(npred=0,nf=nf,nc=nc,ncdims=ncdims)

# finally, setup the prediction grid
npred=30
design.pred=as.matrix(expand.grid(seq(0,3,length=npred),th.init[1]))
dpred.all=rbind(design.pred,d.th,design)
l.pred=makedistlist(dpred.all)
ninfo.pred=list(npred=npred,nf=nf,nc=nc,ncdims=ncdims)



# 6a. Fit Bayesian calibration model
############################
source("calibration.r")

pii=list(af=100,bf=1,az=5,bz=5,adel=500,bdel=5,rhoa=rep(5,nxdims),rhob=rep(1,nxdims),
	    psia=rep(5,ncdims),psib=rep(1,ncdims),rdla=rep(5,nxdims),rdlb=rep(5,nxdims))
mh=list(rr=.03,rp=.1,re=.1,rf=50,rz=.5,rl=.7,rth=.15)

set.seed(88) # just to replicate my run
fit6=calibrate(y,l.des,ninfo,5000,pii,mh,last=1000,rho.force=0.9,psi.force=0.28,rhodel.force=0.7)



# 6b. Draw posterior predictions
############################
fitp6=predict(fit6,l.pred,ninfo.pred)


# 6c. Fit again, but this time with weaker prior on discrepancy
############################
pii=list(af=100,bf=1,az=5,bz=5,adel=5,bdel=5,rhoa=rep(5,nxdims),rhob=rep(1,nxdims),
	    psia=rep(5,ncdims),psib=rep(1,ncdims),rdla=rep(5,nxdims),rdlb=rep(5,nxdims))

set.seed(88) # just to replicate my run
fit6b=calibrate(y,l.des,ninfo,5000,pii,mh,last=1000,rho.force=0.9,psi.force=0.28,rhodel.force=0.7)




# 6d. Make some plots
############################
eta6=fitp6$eta.pred*sdf+mf
zz6=fitp6$z.pred*sdf+mf
bias6=zz-eta
eta.mu6=apply(eta6,2,mean)
eta.sd6=apply(eta6,2,sd)
zz.mu6=apply(zz6,2,mean)
zz.sd6=apply(zz6,2,sd)
bias.mu6=apply(bias6,2,mean)
bias.sd6=apply(bias6,2,sd)


par(mfrow=c(1,1))
par(mar=c(5,5,4,5)+.3,cex.lab=2.7,cex.axis=2.2)
plot(d.th[,1],yf.unscaled,pch=20,cex=3,col="red",xlim=c(0,3),ylim=c(0,70),xlab="time",ylab="height")
lines(design.pred[,1],zz.mu6,col="green",lwd=2)
lines(design.pred[,1],zz.mu6-1.96*zz.sd6,col="green",lty=2)
lines(design.pred[,1],zz.mu6+1.96*zz.sd6,col="green",lty=2)
lines(design.pred[,1],eta.mu6,col="blue",lwd=2)
lines(design.pred[,1],eta.mu6-1.96*eta.sd6,col="blue",lty=2)
lines(design.pred[,1],eta.mu6+1.96*eta.sd6,col="blue",lty=2)
par(new=TRUE)
plot(design.pred[,1],bias.mu6,col="orange",type='l',lwd=2,xlim=c(0,3),ylim=c(-50,50),axes=FALSE,bty="n",xlab="",ylab="")
lines(design.pred[,1],bias.mu6-1.96*bias.sd6,col="orange",lty=2)
lines(design.pred[,1],bias.mu6+1.96*bias.sd6,col="orange",lty=2)
axis(side=4,at=pretty(c(-10,10)))
abline(h=0,col="grey",lty=3,lwd=2)
mtext("discrepancy",side=4,line=3,cex=2.7)
mtext("(b)",line=2,adj=1,cex=2.7)


# 6e. Make plot comparing the two posteriors for gravity with wrong model
#     along with posterior for gravity from correct model from 5.
png("toy7.png",width=1016,height=508)
par(mar=c(5.5,6.5,4,5)+.3,mgp=c(4.5,1,0),cex.lab=2.7,cex.axis=2.2)
par(mfrow=c(1,2))
plot(density(fit$theta[,1]*(r2[2]-r2[1])+r2[1]),xlab=expression(paste("gravity (",m,"/",s^2,")",sep="")),xlim=c(5,15),main="",lty=1,lwd=1)
abline(v=g.true,lty=2)
mtext("(c)",line=1,adj=1,cex=2.7)

plot(density(fit6$theta[,1]*(r2[2]-r2[1])+r2[1]),xlab=expression(paste("gravity (",m,"/",s^2,")",sep="")),xlim=c(5,15),main="",lty=1,lwd=1)
lines(density(fit6b$theta[,1]*(r2[2]-r2[1])+r2[1]),lty=3,lwd=1)
abline(v=g.true,lty=2)
mtext("(d)",line=1,adj=1,cex=2.7)
dev.off()




#
# 7. Now consider different combinations of M1 vs M2 runs available representing
#    the tradeoff of taking more cheap M1 runs and/or more expensive M2 runs.
##########################################################################################################################

set.seed(99)
n=20
k=3

# Make plot comparing the gravity posterior as we vary the number of runs from 
# the cheap drag-free model versus the expensive draggy model.
png("toy8.png",width=2540,height=1016)
par(mar=c(5.8,6.8,4,5)+.3,mgp=c(4.5,1,0),cex.lab=3.7,cex.axis=3.2)
par(mfcol=c(3,5))


# subselect the design in a way that M2 runs are preferred to be later in time, which
# is where they are more useful.
n.m1=c(2,6,10,14,18)
for(nm1 in n.m1) {
	x.design1=as.matrix(cbind(read.table(paste("d2n",nm1,".txt",sep="")),0))
	x.design2=as.matrix(read.table(paste("d3n",20-nm1,".txt",sep="")))
	x.design1=x.design1/n # rescale to 0,1
	x.design1[,1]=x.design1[,1]*3 # rescale to 0,3
	x.design1[,2]=x.design1[,2]*(15-5)+5 # rescale to 5,15
	x.design1[,3]=x.design1[,3]*100 # rescale to 0,100
	x.design2=x.design2/n # rescale to 0,1
	x.design2[,1]=x.design2[,1]*3 # rescale to 0,3
	x.design2[,2]=x.design2[,2]*(15-5)+5 # rescale to 5,15
	x.design2[,3]=x.design2[,3]*100 # rescale to 0,100
	x.design=rbind(x.design1,x.design2)


	colnames(x.design)=c("time","gravity","dragcoef")
	f.obs=fM2(x.design[,"time"],x.design[,"dragcoef"],x.design[,"gravity"])

	# Typically model things on normalized scale to simplify specification of priors
	mf=mean(f.obs)
	sdf=sd(f.obs)
	yc=(f.obs-mf)/sdf

	g.true=9.8
	gamma.true=40
	nf=15
	#y.true=fM1(seq(0.1,0.9,length=nf),g.true)
	set.seed(7)
	times=seq(0.1,2.9,length=nf)+runif(nf,min=-.1,max=.1)
	y.true=fM2(times,gamma.true,g.true)
	y.true=(y.true-mf)/sdf
	yf=y.true+rnorm(nf,sd=0.01)
	yf.unscaled=yf*sdf+mf # only needed for RGL plots below.

	# Setup the things required for the calibration model
	th.init=c(0,0)
	d.th=matrix(c(times,rep(th.init[1],nf),rep(th.init[2],nf)),ncol=k,byrow=FALSE)

	# Scale design and d.th.  Here, the first dimension (time) is already on [0,1] so we only have to scale the parameter dimension of design.
	design=x.design
	r2=c(5,15) #range(x.design[,2])
	design[,2]=(design[,2]-r2[1])/(r2[2]-r2[1])
	r3=c(0,100) #range(x.design[,3])
	design[,3]=(design[,3]-r3[1])/(r3[2]-r3[1])

	nc=length(yc)
	y=c(yf,yc)

	design.all=rbind(d.th,design)
	l.des=makedistlist(design.all)

	ncdims=2
	nxdims=1
	ninfo=list(npred=0,nf=nf,nc=nc,ncdims=ncdims)

	# finally, setup the prediction grid
	npred=30
	design.pred=as.matrix(expand.grid(seq(0,3,length=npred),th.init[1],th.init[2]))
	dpred.all=rbind(design.pred,d.th,design)
	l.pred=makedistlist(dpred.all)
	ninfo.pred=list(npred=npred,nf=nf,nc=nc,ncdims=ncdims)


	# Fit Bayesian calibration model
	source("calibration.r")

	pii=list(af=200,bf=1,az=5,bz=5,adel=500,bdel=5,rhoa=rep(5,nxdims),rhob=rep(1,nxdims),
		    psia=rep(5,ncdims),psib=rep(1,ncdims),rdla=rep(5,nxdims),rdlb=rep(5,nxdims))
	mh=list(rr=.03,rp=.1,re=.1,rf=50,rz=.5,rl=.7,rth=.15)

	set.seed(88) # just to replicate my run
	fit7=calibrate(y,l.des,ninfo,5000,pii,mh,last=1000,rho.force=0.9,psi.force=0.28,rhodel.force=0.7)

	# Plot
	plot(x.design[,"time"],x.design[,"dragcoef"],pch=20,cex=2,xlab="time (s)",ylab="Drag Coefficient")
	mtext(paste("# M2 Runs=",20-nm1,sep=""),line=1,adj=0.5,cex=2.7)

	plot(density(fit7$theta[,1]*(r2[2]-r2[1])+r2[1]),xlab=expression(paste("gravity (",m,"/",s^2,")",sep="")),xlim=c(5,15),main="",lty=1,lwd=1)
	abline(v=g.true,lty=2)

	plot(density(fit7$theta[,2]*(r3[2]-r3[1])+r3[1]),xlab=expression(paste("drag (",N,s^2,"/",m^4,")",sep="")),xlim=c(0,100),main="",lty=1,lwd=1)
	abline(v=gamma.true,lty=2)
}
dev.off()




#
# 8. Alternatively, we can use BMA.  Here we need the marginal likelihood.  Assuming
#    independent GP models for each model trajectory conditional on theta, the
#    precision can be analytically integrated out, leaving only the parameters of
#    the correlation matrix R.  For (computational) simplicity, we might just impute an MLE value for R.
##########################################################################################################################

marglik<-function(y,z,alpha,beta)
{
	n=length(y)

	numer=beta^alpha*gamma(alpha+n/2)
	denom=(2*base::pi)^.5*(beta+0.5*t(y-z)%*%(y-z))^(alpha+n/2)*gamma(alpha)
	numer/denom
}


set.seed(99)
nruns=sqrt(20*20)
n=7
k=3
x.design1=as.matrix(expand.grid(seq(0.1,2.9,length=n)))
theta.design=as.matrix(expand.grid(seq(5,15,length=nruns),seq(0,100,length=nruns)))


g.true=9.8
gamma.true=40
times=seq(0.1,2.9,length=n)
y.true=fM2(times,gamma.true,g.true)

# Explore model space using BMA
alpha=10  
beta=1   
Ptheta=rep(0,nrow(theta.design))
z=matrix(0,nrow=nrow(theta.design),ncol=n)
for(i in 1:length(Ptheta)) {
	z[i,]=fM2(x.design1,theta.design[i,2],theta.design[i,1])
	Ptheta[i]=marglik(y.true,z[i,],alpha,beta)
}

# Approximated model probabilities, where models are indexed by theta
Ptheta=Ptheta/sum(Ptheta) #normalize

# BMA mean prediction
zwtd=z
for(i in 1:length(Ptheta))
	zwtd[i,]=zwtd[i,]*Ptheta[i]
z.mu=apply(zwtd,2,sum)

# BMA prediction sd
zvar=z
for(i in 1:length(Ptheta))
	zvar[i,]=(z[i,]-z.mu)^2*Ptheta[i]
z.sd=sqrt(apply(zvar,2,sum))

# BMA theta mean estimate
theta.mu=theta.design
for(i in 1:length(Ptheta))
	theta.mu[i,]=theta.mu[i,]*Ptheta[i]
theta.mu=apply(theta.mu,2,sum)

# BMA theta sd
theta.var=theta.design
for(i in 1:length(Ptheta))
	theta.var[i,]=(theta.design[i,]-theta.mu)^2*Ptheta[i]
theta.sd=sqrt(apply(theta.var,2,sum))


#  Make plots
png("toy6a.png",width=1524,height=508)

par(mar=c(5,5,4,5)+.3,cex.lab=3,cex.axis=2.5)
par(mfrow=c(1,3))
plot(x.design1,y.true,col="red",pch=20,xlim=c(0,3),ylim=c(0,60),xlab="time (s)",ylab="height (m)")
for(i in 1:nrow(z))
	lines(x.design1,z[i,],col="grey",lwd=0.5)
points(x.design1,y.true,col="red",pch=20,cex=4)
lines(x.design1,z.mu,col="blue",lwd=3)
lines(x.design1,z.mu-2*z.sd,col="blue",lty=2)
lines(x.design1,z.mu+2*z.sd,col="blue",lty=2)
mtext("(a)",line=1,adj=1,cex=3)

plot(density(theta.design[,1],weights=Ptheta),xlab=expression(paste("gravity (",m,"/",s^2,")",sep="")),xlim=c(5,15),main="")
abline(v=g.true,lty=2)
mtext("(b)",line=1,adj=1,cex=3)

plot(density(theta.design[,2],weights=Ptheta),xlab=expression(paste("drag (",N,s^2,"/",m^4,")",sep="")),xlim=c(0,100),main="")
abline(v=gamma.true,lty=2)
mtext("(c)",line=1,adj=1,cex=3)

dev.off()




# 8b. Now do BMA again, but using the wrong model.
############################
set.seed(99)
nruns=sqrt(20*20)
n=7
k=2
x.design1=as.matrix(expand.grid(seq(0.1,2.9,length=n)))
theta.designb=as.matrix(expand.grid(seq(5,15,length=nruns)))


g.true=9.8
gamma.true=40
times=seq(0.1,2.9,length=n)
y.true=fM2(times,gamma.true,g.true)

# Explore model space using BMA
alpha=10  
Pthetab=rep(0,nrow(theta.designb))
zb=matrix(0,nrow=nrow(theta.designb),ncol=n)
for(i in 1:length(Pthetab)) {
	zb[i,]=fM1(x.design1,theta.designb[i,1])
	Pthetab[i]=marglik(y.true,zb[i,],alpha,beta)
}

# Approximated model probabilities, where models are indexed by theta
Pthetab=Pthetab/sum(Pthetab) #normalize

# BMA mean prediction
zwtd=zb
for(i in 1:length(Pthetab))
	zwtd[i,]=zwtd[i,]*Pthetab[i]
z.mub=apply(zwtd,2,sum)

# BMA prediction sd
zvar=zb
for(i in 1:length(Pthetab))
	zvar[i,]=(zb[i,]-z.mub)^2*Pthetab[i]
z.sdb=sqrt(apply(zvar,2,sum))

# BMA theta mean estimate
theta.mub=theta.designb
for(i in 1:length(Pthetab))
	theta.mub[i,]=theta.mub[i,]*Pthetab[i]
theta.mub=apply(theta.mub,2,sum)

# BMA theta sd
theta.varb=theta.designb
for(i in 1:length(Pthetab))
	theta.varb[i,]=(theta.designb[i,]-theta.mub)^2*Pthetab[i]
theta.sdb=sqrt(apply(theta.varb,2,sum))


#  Make plots
png("toy6b.png",width=1016,height=508)

par(mar=c(5,5,4,5)+.3,cex.lab=3,cex.axis=2.5)
par(mfrow=c(1,3))
plot(x.design1,y.true,col="red",pch=20,xlim=c(0,3),ylim=c(0,60),xlab="time (s)",ylab="height (m)")
for(i in 1:nrow(zb))
	lines(x.design1,zb[i,],col="grey",lwd=0.5)
points(x.design1,y.true,col="red",pch=20,cex=4)
lines(x.design1,z.mub,col="blue",lwd=3)
lines(x.design1,z.mub-2*z.sd,col="blue",lty=2)
lines(x.design1,z.mub+2*z.sd,col="blue",lty=2)
mtext("(a)",line=1,adj=1,cex=3)

plot(density(theta.designb[,1],weights=Pthetab),xlab=expression(paste("gravity (",m,"/",s^2,")",sep="")),xlim=c(5,15),main="")
abline(v=g.true,lty=2)
mtext("(b)",line=1,adj=1,cex=3)

dev.off()


# 8c. Make a final plot -- basically plot from 8a, but add the posterior for gravity
#     from BMA using the wrong model in 8b.
############################

png("toy6.png",width=1524,height=508)

par(mar=c(6,7.5,4,5)+.3,mgp=c(5,1,0),cex.lab=3.8,cex.axis=2.2)
par(mfrow=c(1,3))
plot(x.design1,y.true,col="red",pch=20,xlim=c(0,3),ylim=c(0,60),xlab="time (s)",ylab="height (m)")
for(i in 1:nrow(z))
	lines(x.design1,z[i,],col="grey",lwd=0.5)
points(x.design1,y.true,col="red",pch=20,cex=4)
lines(x.design1,z.mu,col="blue",lwd=3)
lines(x.design1,z.mu-2*z.sd,col="blue",lty=2)
lines(x.design1,z.mu+2*z.sd,col="blue",lty=2)
mtext("(a)",line=1,adj=1,cex=2.7)

plot(density(theta.designb[,1],weights=Pthetab),xlab=expression(paste("gravity (",m,"/",s^2,")",sep="")),xlim=c(5,15),main="",lty=3)
abline(v=g.true,lty=2)
mtext("(b)",line=1,adj=1,cex=2.7)
lines(density(theta.design[,1],weights=Ptheta),lty=1)

plot(density(theta.design[,2],weights=Ptheta),xlab=expression(paste("drag (",N,s^2,"/",m^4,")",sep="")),xlim=c(0,100),main="")
abline(v=gamma.true,lty=2)
mtext("(c)",line=1,adj=1,cex=2.7)

dev.off()


