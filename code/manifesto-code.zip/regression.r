 #    regression.r: Bayesian Implementation of GP Regression Model
 #    Copyright (C) 2016  Matthew T. Pratola <mpratola@stat.osu.edu>

 #    This program is free software: you can redistribute it and/or modify
 #    it under the terms of the GNU Affero General Public License as published
 #    by the Free Software Foundation, either version 3 of the License, or
 #    (at your option) any later version.

 #    This program is distributed in the hope that it will be useful,
 #    but WITHOUT ANY WARRANTY; without even the implied warranty of
 #    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #    GNU Affero General Public License for more details.

 #    You should have received a copy of the GNU Affero General Public License
 #    along with this program.  If not, see <http://www.gnu.org/licenses/>.


# Bayesian Implementation of GP Regression Model
#
# Data:   y(xi) = eta(xi), i=1,...,n ; xi=1xK vector
#
#
# Likelihood: L(Y|.) propto. 1/[(2pi)^(n/2)*det(E)^(1/2)]exp(-(Y')(Einv)(Y)) ; Y=[y(x1),...,y(xn)]
# where,
#         E=1/lambdaz*[R(.,.;rho)]
#
# Priors:
#         pi(lambdaz) propto. lambdaz^(az-1)exp(-bz*lambdaz)     [Gamma prior]
#         pi(rhoz_k) propto. rhoz_k^(rhoa-1)(1-rhoz_k)^(rhob-1)  [Beta prior]
#
# Posterior:
#         pi(.|Y) propto. L(Y|.)pi(lambdaz)pi(rhoz_1)*...*pi(rhoz_K)
#
# We fit the model using MCMC with adaptive stepwidths for the uniform proposal distributions.
#
#

logp<-function(y,lambdaz,rhoz,l.dez,pi)
{
  az=pi$az; bz=pi$bz

  if(any(rhoz<=0) || any(rhoz>=1))
     logposterior=-Inf
  else
  {
    n=length(y)
    k=length(rhoz)
    In=diag(n)
    Rz=rhomat(l.dez,rhoz)$R
    Ez=1/lambdaz*(Rz+In*1e-14)
    cholEz=chol(Ez)
    Ezinv=chol2inv(cholEz)
    logdetEz=2*sum(log(diag(cholEz)))
  
    logpz=-1/2*logdetEz-1/2*t(y)%*%Ezinv%*%(y)
    logplambdaz=(az-1)*log(lambdaz)-bz*lambdaz
    logprhoz=0
    for(i in 1:k) logprhoz=logprhoz+(pi$rhoa[i]-1)*log(rhoz[i])+(pi$rhob[i]-1)*log(1-rhoz[i])
    
    logposterior=logpz+logplambdaz+logprhoz
  }
  logposterior
}


# Gibbs/MCMC Sampler
# y - observed response
# l.dez - distances in my format
# N - number of Gibbs/MCMC iterations for the sampler
# pi=list(az=5,bz=5,rhoa=rep(1,k),rhob=rep(5,k))
# mh=list(rr=.07)
regress<-function(y,l.dez,N,pi,mh,last=1000,adapt=TRUE)
{
  if(N<2000) stop("N>=2000 please\n")
  
  last=last-1
  n=length(y)
  k=length(l.dez)

  draw.lambdaz=rep(NA,N)
  draw.rhoz=matrix(NA,nrow=N,ncol=k)

  rr=rep(mh$rr,k)

  # initial guesses
  draw.lambdaz[1]=1/var(y)
  draw.rhoz[1,]=rep(.5,k)
  
  #accept/reject ratio trackers
  accept.rhoz=rep(0,k)

  lastadapt=0
  
  In=diag(n)
  one=rep(1,n)
  rhoz.new=rep(NA,k)

  cat("\n Bayesian Gaussian Process Interpolation model")
  cat("\n The last ",last," samples from the posterior will be reported")
  cat("\n The stepwidth for uniform corr. param proposal distn is rr=",rr)
  cat("\n Prior params:  az=",pi$az," bz=",pi$bz)
  cat("\n ----------------------------------------------------------------\n\n\n")

  for(i in 2:N)
  {

    # Draw the correlation parameters (Metropolis-Hastings steps)
    draw.rhoz[i,]=draw.rhoz[i-1,]
    for(j in 1:k)
    {
      rhoz.new=draw.rhoz[i,]
      rhoz.new[j]=runif(1,draw.rhoz[i-1,j]-rr[j],draw.rhoz[i-1,j]+rr[j])
      a=min(0,logp(y,draw.lambdaz[i-1],rhoz.new,l.dez,pi)
             -logp(y,draw.lambdaz[i-1],draw.rhoz[i,],l.dez,pi))
      if(log(runif(1))<a)
      {
        draw.rhoz[i,j]=rhoz.new[j]
        accept.rhoz[j]=accept.rhoz[j]+1
      }
    }

    # Draw the marginal precision of the data (Gibbs step)
    Rz=rhomat(l.dez,draw.rhoz[i,])$R
    Rz=Rz+In*1e-14  #cheat
    cholRz=chol(Rz)
    Rzinv=chol2inv(cholRz)
    draw.lambdaz[i]=rgamma(1,pi$az+n/2,pi$bz+0.5*t(y)%*%Rzinv%*%y)


    cat(i/N*100," percent complete\r")

    # Adaptive MCMC stuff:
    # adapt the proposal step every N/20 iterations, but only for the first 50% of the iterations
    if(adapt && i%%(N/20)==0 && i<(N*.5+1))
    {
      rate.rhoz=accept.rhoz/(i-lastadapt)
      cat("Adapting rates from ",rate.rhoz,"\n");
      for(j in 1:k)
        if(rate.rhoz[j]>.49 || rate.rhoz[j]<.39) rr[j]=rr[j]*rate.rhoz[j]/.44
      lastadapt=i
      accept.rhoz=rep(0,k)
    }

  }

  cat("\n Complete.")
  rate.rhoz=accept.rhoz/(i-lastadapt)
  cat("[rate.rhoz=",rate.rhoz,"]\n")
  
  return(list(y=y,lambdaz=draw.lambdaz[(N-last):N],rhoz=as.matrix(draw.rhoz[(N-last):N,])))
}


# I had a prediction function somewhere at some point...
# Here is a quick hack that uses gp.crealize from gpfuns.r
predict<-function(x.pred,x.design,fit)
{
  N=length(fit$lambdaz)
  np=nrow(x.pred)
  fp.draws=matrix(0,nrow=N,ncol=np)
  l.p=makedistlist(rbind(x.pred,x.design))

  for(i in 1:N)
    fp.draws[i,]=gp.crealize(l.p,fit$y,0,fit$lambdaz[i],as.vector(fit$rhoz[i,]))

  return(list(draws=fp.draws,fp=apply(fp.draws,2,mean),fp.sd=apply(fp.draws,2,sd)))
}

